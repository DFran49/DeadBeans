using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class ItemStatsList
{
    public List<ItemStats> items;
}
using UnityEngine;

public enum ItemSubtype
{
    weapon,
    armor,
    material,
    consumable
}

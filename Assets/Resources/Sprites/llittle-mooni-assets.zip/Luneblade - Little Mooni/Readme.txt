JESSHIYOO ASSET PACK
====================

Thank you for downloading this pack!

📌 TIPS:
------------
> Use the spritesheet in any game engine such as Unity, Godot, RPG maker etc.
> Import as multiple sprite

📌 REMINDER:
------------
> Before you slice the sprite sheets, make sure to set it "144x144" pixels
  so it match with the character's canva size

✉️ CONTACT:
------------
Made my Jesshiyoo.

Email:  mrderpy0321@gmail.com
Itch: https://jesshiyoo.itch.io/
Discord:  Jess / jesshiyoo
X:  @jesshiyoo